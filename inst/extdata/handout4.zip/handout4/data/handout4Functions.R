plot.tsq <- function(pointest, CI) {
  cover.curr <- apply(CI - tau.true, 1, prod) < 0
  plot(
    treat,
    pointest,
    type = "n",
    ylim = range(c(m1$CIs.tau, b1.CIs)),
    xlab = "",
    ylab = ""
  )
  lines(treat, treat * 0 + tau.true)
  segments(
    x0 = treat,
    x1 = treat,
    y0 = CI[, 1],
    y1 = CI[, 2],
    col = ifelse(cover.curr,
                 gray(.7),
                 "black")

  )
  mtext("Estimated Effect", 1, line = 2.2, cex = 1.25)
  mtext("True Effect", 2, line = 2, cex = 1.25)

  points(treat, pointest, pch = 19, cex = .5)
  print(mean(cover.curr))

}
b1.CIs <- NULL
